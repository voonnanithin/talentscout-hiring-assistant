import os
import json
import hashlib
import secrets
from typing import Dict, List

DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "candidates.jsonl")

def _hash(value: str, salt: str) -> str:
    h = hashlib.sha256()
    h.update((salt + value).encode("utf-8"))
    return h.hexdigest()

def save_candidate_record(candidate: Dict, questions: List[str], messages: List[Dict]):
    os.makedirs(os.path.dirname(DATA_PATH), exist_ok=True)
    salt = secrets.token_hex(8)
    record = {
        "full_name": candidate.get("full_name"),
        "email_hash": _hash(candidate.get("email",""), salt),
        "phone_hash": _hash(candidate.get("phone",""), salt),
        "years_experience": candidate.get("years_experience"),
        "desired_position": candidate.get("desired_position"),
        "location": candidate.get("location"),
        "tech_stack": candidate.get("tech_stack"),
        "questions": questions,
        "conversation": [m for m in messages if m["role"] in ("assistant","user")],
        "created_at": candidate.get("timestamp"),
        "salt": salt  # kept locally to allow dedup; remove if undesired
    }
    with open(DATA_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")
